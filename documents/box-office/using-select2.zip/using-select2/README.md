# Using Select2

A Pen created on CodePen.io. Original URL: [https://codepen.io/riyos94/pen/VyBdBz](https://codepen.io/riyos94/pen/VyBdBz).

Sample of select2